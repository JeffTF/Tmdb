// import 'package:flutter/material.dart';
// class Custom<T> extends StatelessWidget {
//   const Custom({Key? key, required this.future}) : super(key: key);
//   final Future<T> future;
//
//   @override
//   Widget build(BuildContext context) {
//     return FutureBuilder(future: future,builder: (context,snapShot){
//          return CustomScrollView(
//            slivers: [
//              SliverAppBar(
//                flexibleSpace: FlexibleSpaceBar(
//                  background: Image.network("${snapShot.data[]}"),
//                ),
//              )
//            ],
//          );
//     });
//   }
// }
