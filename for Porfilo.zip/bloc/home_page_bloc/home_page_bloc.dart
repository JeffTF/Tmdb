import 'package:flutter/cupertino.dart';

class HomePageBloc extends ChangeNotifier{

}